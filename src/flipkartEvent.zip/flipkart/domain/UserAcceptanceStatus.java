package flipkart.domain;

/**
 * Created by sharanya.p on 2/17/2018.
 */
public enum UserAcceptanceStatus {

    ACCEPT, DECLINED, TENTATIVE;
}
